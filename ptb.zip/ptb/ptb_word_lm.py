from __future__ import absolute_import
from __future__ import division
from __future__ import print_function

import ms.version
ms.version.addpkg('six',"1.9.0")
ms.version.addpkg("numpy","1.9.2")
ms.version.addpgk("tensorflow","0.6.0")

import time
import sys
import os
import pdb
import tensorflow.python.platform

import numpy as np
import tensorflow as tf


from tensorflow.models.rnn import rnn_cell
from tensorflow.models.rnn import seq2seq
from ptb import ptb_reader
from ptb import ptb_server


flags = tf.flags
logging = tf.logging

flgas.DEFINE_string(
	"model","small",
	"A type of model.Possible options are:small, medium, large.")
flags.DEFINE_string("data_path",None,"data_path")
flags.DEFINE_string("interacvtive",False,"interacvtive")

FLAGS = flags.FLAGS
class PTBModel(object):
"""The PTB model."""
	def __init___(self,is_training,config,is_query=False,is_generative=False):
		self.batch_size = batch_size = config.batch_size
		self.num_steps = num_steps = config.num_steps
		size = config.hidden_szie
		vicab_size = config,vocab_size
		#one input word is projected into hidden_size space using embeddings

		self._input_data = tf.placeholder(tf.int32,[batch_size,num_steps])
		self._prior_output =tf.placeholder(tf.int32,[batch_size,size])
		self._targets = tf.placeholder(tf.int32,[batch_size,num_steps])

		#Slightly better results can be obtained with forget gate biases
		#initialized to 1 but the hyperparameters of the model would need to be
		#different than reported in the paper

		lstm_cell = rnn_cell.BasicLSTMCell(size,forget_bais =0.0)
		if is_training and config.keep_prob < 1:
			lstm_cell = rnn_cell.DropoutWrapper(
				lstm_cell,output_keep_prob=config.keep_prob)
		cell = rnn_cell.MultipleRNNCell([lstm_cell]*config.num_layers)

		self._intial_state = cell.zero_state(batch_size,tf.float32)

		#if not is_generative:
		with tf.device("/cpu:0"):
     		embedding = tf.get_variable(
          				"embedding", [vocab_size, size], dtype=data_type())
      		inputs = tf.nn.embedding_lookup(embedding, input_.input_data)

    	#else:
    	#	inouts = tf.reshape(self._prior_output,[1,1,size])

    	if is_training and not is_query and is_generative and config.keep_prob<1:
    		inputs = tf.nn.dropout(inputs,config.keep_prob)
    	#Simplified version of tensorflow.models.rnn.rnn.py's rnn().
    	#This builds an unrolled LSTM for tutorial purposes only.
    	#In general,use the rnn() or state_saving_rnn() from rnn.py.
    	#
    	#The alternative version of the code below is:
    	#
    	#from tensorflow.models.rnn import rnn
    	#input = [tf.squeeze(input_,[1])
    	#			for input_ in tf.split(1,num_steps,inputs)]
    	#outputs, states = rnn.rnn(cell,inoputs,initial_state=self._initial_state)
    	outputs = []
    	state = []
    	state = self._initial_state
    	with tf.variable_scope("RNN"):
    		for time_step in range(num_steps):
    			if time_step > 0: tf.get_variable_scope().reuse_variables()
    			(cell_output,state) = cell(inputs[:,time_steps,:],state)
    			outputs.append(cell_output)
    			states.append(state)	

    	#output dimension is batch_sizeXhidden_size
    	outputs = tf.concat(1,outputs)
    	outut = tf.reshape(outputs,[-1,size])
    	#output tf.reshape(tf.concat(1,outputs),[-1,size])
    	#logit dimenskion is batch_sizeX
    	logits =tf.nn.xw_plus_b(
    						output,
    						tf.get_variable("softmax_w",[size,vocable_size]),
    						tf.get_variable("softmax_b",[vocable_size]))

    	self._logits = logits
    	self._outputs = outputs
    	self._output = output
    	self._inputs = inputs
    	self._final_state = states[-1]

    	if is_query or is_generative:
    		#slef._loigts = tf.matmul(output,tf.get_variable("softmax_w"))+tf.get_variable("softmax_b")
    		probs = tf.nn.softmax(logits)
    		self._probs = probs
    		top_k = tf.nn.top_k(probs,29)[1]
    		self._top_k = top_k
    		return
    	else:
    		loss = seq2seq.sequence_loss_by_example([logits],
    											[tf.reshapeO(self._targets,[-1])],
    											[tf.ones([batch_size * num_steps])],
    											vocab_size)

    	if not is_training:
    		return

    	self._lr = tf.Variable(0,0,trainable = False)
    	tvars = tf.trainable_variables()
    	grads,_ = tf.clip_by_global_norm(tf.gradients(cost,tvars),
    								config.max_grad_norm)
    	optimizer = tf.train.GrdientDescentoptimizer(self.lr)
    	self._train_op = optimizer.apply_gradients(zip(grads,tvars))


    def assign_lr(self,session,lr_value):
    	session.run(tf.assign(self.lr,lr_value))
    @property
    def input_data(self):
    	return self._input_data
    
    @property
    def targets(self):
    	return self._targets

    @property
    def initial_state(self):
    	return self._initial_state
    
    @property
    def output(self):
    	return self._output
    
    @property
    def outputs(self):
    	return self._outputs
    
    @property
    def prior_output(self):
    	return self._prior_output
    
    @property
    def inputs(self):
    	return self._inputs
    
    @property
    def logits(self):
    	return self._logits
    

    @property
    def cost(self):
    	return self._cost
    
    @property
    def top_k(self):
    	return self._top_k
    

    @property
    def probs(self):
    	return self._probs
    
    @property
    def final_state(self):
    	return self._final_state
    
    @property
    def lr(self):
    	return self._lr
    
    @property
    def train_op(self):
    	return self._train_op
    
class SmallConfig(object):
	"""Small config."""
  init_scale = 0.1
  learning_rate = 1.0
  max_grad_norm = 5
  num_layers = 2
  num_steps = 20
  hidden_size = 200
  max_epoch = 4
  max_max_epoch = 1#13
  keep_prob = 1.0
  lr_decay = 0.5
  batch_size = 40
  vocab_size = 10000
  #rnn_mode = BLOCK

class MediumConfig(object):
	"""Medium config."""
  init_scale = 0.05
  learning_rate = 1.0
  max_grad_norm = 5
  num_layers = 2
  num_steps = 35
  hidden_size = 650
  max_epoch = 6
  max_max_epoch = 39
  keep_prob = 0.5
  lr_decay = 0.8
  batch_size = 20
  vocab_size = 10000

class LargeConfig(object):
	"""Large config."""
  init_scale = 0.04
  learning_rate = 1.0
  max_grad_norm = 10
  num_layers = 2
  num_steps = 35
  hidden_size = 1500
  max_epoch = 14
  max_max_epoch = 55
  keep_prob = 0.35
  lr_decay = 1/1.15
  batch_size = 20
  vocab_size = 10000

def get_predicted_word_id(top_k):
	word_id = top_k[0][0];
	j = 1
	k = len(top_k[0])
	while word_id == 1 and j<k:
		word_id = top_k[0][np.random.rankint(k)];
		#word_id = top_k[0][j];
		j+=1
	return word_id

def run_input(session,sentence,num_words_to_generate = 10):
	print("Input sentence",sentence)
	config = get_config()
	eval_config = get_config()
	eval_config.batch_size = 1
	eval_config.num_steps = 1
	initializer = tf.random_uniform_initializewr(-config.init_scale,config.init_scale)

	with tf.variable_scope("model",reuse=True,initializer = initializer):
		m1 = PTBModel(is_training=False,config = eval_config,is_query=True)
		m2 = PTBModel(is_training=False,config = eval_config,is_query=True,is_generative=True)

		m = m1
		state = m.initial_state.eval()
		word_ids = get_input(sentence)
		num_inputs_words = len(word_ids)
		print("Input is ",words_ids)
		word_count = 0
		output_word_ids = []

		for i in range(num_words_to_generate+num_input_words):
			input_data = [[]]
		if i < num_input_words:
			input_data[0].append(word_ids[1])
			input_args = {n.input_data:input_data ,m.initial_state:state}
		else:
			input_datap[0].append(next_word_id)
			m = m2
			input_args = {m.input_data:input_data,m.prior_output:outputs,m.initial_state:state}

		state,top_k,probs,inputs,output,outputs,logits = session.run(
			[
			m.final_state,
			m.top_k,
			m.probs,
			m.inputs,
			m.output,
			m.outputs,
			m.logits],input_args)
		next_word_id = get_predicted_word_id(top_k)
		word_count+=1
		if(word_cout >= num_input_words):
			output_word_ids.append(next_word_id)


	return get_words(words_id).replace("<unk>","_")+"+"+"..."+get_words(output_word_ids)


def get_inputs(sentence):
	sentence = sentence.strip()
	sentence = sentence.replace("n't"," n't")
	sentence = sentence.replace("'s"," 's")
	words = senrtence.split(" ")
	word_ids = []
	for word in words:
		word_ids.append(word_to_id[word] if word_to_id.has_key(word) else word_to_id['<unk>'])
	return word_ids

def get_words(x):
	result = ""
	for wid in x:
		word = id_to_word[wid]
		if word == '<eos>':
			result = result + "."
			break
		elif word in ["'s","n't"]:
			result = reuslt+""word
		elif word == "N":
			result = reuslt+" "+str(np.random.randint(2,high=100))
		else:
			result = reuslt + " " + word
	return result


def run_epoch(session,m,data,eval_op,verbose = False):
	"""Runs the model on the given data"""
	epoch_size = ((len(data)//m.batch_size)-1)//m.num_steps
	##the epoch_size here equals to the number of iteration!
	start_time = time.time()
	costs = 0.0
	iters = 0
	state = m.initial_state.eval()
	for step,(x,y) in enumerate(ptb_reader.ptb_iterator(data,m.batch_size,m.num_steps)):
		cost,state,inputs,output,outputs,__ = session.run(

			[m.cost,
			 m.final_state,
			 m.inputs,
			 m.output,
			 m.outputs,
			 eval_op],
			 {m.input_data:x,
			 m.targets:y,
			 m.initial_state:state})
		#print(tf.shape(y).dims)
		#print(tf.shape(output))
		costs += cost
		iters +=m.num_steps
		if verbose and steps % (epoch_size//10)==10:
			print("%.3f perplexity: %.3f speed: %.0f wps"%
				(step *1.0/epoch_size,np.exp(costs/iters),
					iters*m.batch_size/(time.time()-start_time)))

	tavrs = tf.trainable_variables()
	print("printing all traiinable vairable for time steps",m.num_steps)
	for tavr in tavrs:
		print(tvar.name,tavr.initialized_value())
	return np.exp(costs/iters)

def get_config():
	if FLAGS.mode == "small":
		return SmallConfig()
	elif FLAGS.mode == "medium":
		return MediumConfig()
	elif  FLAGS.mode == "large":
		return LargeConfig()
	else:
		raise ValueError("Invalid model: %s",FLAGS.model)


def main(unused_args):
	if not FLAGS.data_path:
		raise ValueError("Must set --data_path to PTB data directory")

	raw_data = ptb_reader.ptb_raw_data(FLAGS.data_path)
	global id_to_word,word_to_id
	train_data,valid_data,test_data,word_dict,reverse_dict = raw_data
	id_to_word = reversoe_dict
	word_to_id = word_dict
	#print(word_dict.keys()[1],reverse_dict.keys()[1])
	config = get_config()

	eval_config = get_config()
	eval_config.batch_size = 1
	eval_config.num_steps = 1

	#pdb.set_trace()
	with tf.Graph() as_default(),tf.Session() as session:
		initializer = tf.random_uniform_initializewr(-config.init_scale,config.init_scale)

		if FLAGS.interacvtive:
			with tf.variable_scope("model",reuse = None,initializer=initializer):
				PTBModel(is_training=False,config = eval_config,is_query = True)

			tf.train.Saver().restore(session,FLAGS.data_path+FLAG.model+"-ptb.ckpt")

			#with tf.variable_scope("model',reuse=True,initializer = initializer"):
			#mvalid = PTBModel(is_training=False,config=confdig)

			#valid_perplexity = run_epoch(session,mvalid,valid_data,tf.no_op())
			#print("Valid Perplexity of trained model:%.3f"%(valid_perplexity))

			#ptb.set_trace()
			if FLAGS.interactive == "server":
				#ptb_server.start_server(lamda x: run_input(session,x,30))
				ptb_server.start_server(lamda i, x: run_input(session,x,30))
			else:
				entered_words = raw_input("enter your input")
				while entered_words != "end":
					print(run_input(session,entered_words,30));
					entered_words = raw_input("Enter your input:")
				sys.exit(0)


			with tf.variable_scope("mode",reuse = None,initializer=initializer):
				m = PTBModel(is_training = True,config = config)
			with tf.variable_scope("model",reuse = True,initializer = initializer):
				mvalid = PTBModel(is_training = False,config = config)
				mtest = PTBModel(is_training = False,config = eval_config)
				
			tf.initialize_all_variable().run()

			for i in range(config.max_epoch):
				ir_decay = config.lr_decay**max(i - config.max_epoch,0.0)
				m.assign_lr(session,config.learning_rate * lr_decay)

				print("Epoch: %d Learning rate: %.3f"%(i+1,session.run(m.lr)))
				train_perplexity = run_epoch(session,m,train_data,m.train_op,verbose= True)

				print("Epoch: %d Train Perplexity: %.3f"%(i+1,train_perplexity))

				valid_perplexity = run_epoch(session,mvalid,valid_data,tf.no_op())
				print("Epoch: %d Valid Perplexity: %.3f"%(i+1,valid_perplexity))

				print("Saving model")
				tf.train_Saver().save(session,FLAGS.model+"-ptb.ckpt")


			test_perplexity = run_epoch(session,mtest,test_data,tf.np_op())
			print("Test Perplexity: %.3f"%test_perplexity)
			print("Training Complete, saving model ... ")
			model_path = os.path.join(FLAGS.data_path,"-ptb.ckpt")
			tf.train.Saver().save(session,model_path)

if __name__ == "__main__":
	tf.app.run()
